/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'motion/react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutSection } from './components/AboutSection';
import { ProjectsSection } from './components/ProjectsSection';
import { ExperienceSection } from './components/ExperienceSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { ScrollProgressIndicator } from './components/ScrollProgressIndicator';
import { ThemeMode } from './types';
import { AnalyticsService } from './services/analyticsService';

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>('dark-crimson');
  const [activeSection, setActiveSection] = useState('hero');
  const containerRef = useRef<HTMLDivElement>(null);

  // High-performance Framer Motion Parallax Hooks
  const { scrollYProgress } = useScroll();
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  });

  // Parallax transforms for ambient atmospheric light effects across the page
  const ambientOrb1Y = useTransform(scrollYProgress, [0, 1], [-40, 520]);
  const ambientOrb2Y = useTransform(scrollYProgress, [0, 1], [150, -350]);
  const contentFadeY = useTransform(scrollYProgress, [0, 0.05], [0, -10]);

  useEffect(() => {
    // Initialize analytics telemetry
    AnalyticsService.initialize();
    AnalyticsService.trackEvent('page_view', 'Home Page View');

    // Section Scroll Spy for accurate navigation
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { threshold: 0.25 }
    );

    const sectionIds = ['hero', 'about', 'projects', 'experience', 'contact'];
    sectionIds.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const isLight = theme === 'light-contrast';

  return (
    <div 
      ref={containerRef}
      className={`min-h-screen transition-colors duration-300 relative overflow-x-hidden ${
        isLight
          ? 'bg-slate-50 text-slate-900'
          : 'bg-[#08090d] text-slate-100'
      }`}
    >
      {/* Top Parallax Scroll Progress Bar */}
      <motion.div
        style={{ scaleX: smoothProgress }}
        className="fixed top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-red-600 via-orange-500 to-amber-400 origin-left z-50 shadow-[0_0_12px_rgba(240,90,40,0.8)]"
      />

      {/* Floating Parallax Ambient Orbs */}
      <motion.div
        style={{ y: ambientOrb1Y }}
        className="fixed top-1/4 -right-44 w-96 h-96 rounded-full bg-orange-600/10 blur-[120px] pointer-events-none z-0"
      />
      <motion.div
        style={{ y: ambientOrb2Y }}
        className="fixed top-2/3 -left-44 w-96 h-96 rounded-full bg-red-600/10 blur-[130px] pointer-events-none z-0"
      />

      {/* Sticky Header with Personal Branding */}
      <Navbar
        theme={theme}
        onThemeChange={setTheme}
        activeSection={activeSection}
      />

      {/* Main Content Sections with Parallax Scrolling */}
      <main className="relative z-10">
        <HeroSection 
          theme={theme} 
        />

        <AboutSection 
          theme={theme} 
        />

        <ProjectsSection 
          theme={theme} 
        />

        <ExperienceSection 
          theme={theme} 
        />

        <ContactSection 
          theme={theme} 
        />
      </main>

      {/* Footer */}
      <Footer 
        theme={theme} 
      />

      {/* Floating Instant WhatsApp Button */}
      <FloatingWhatsApp />

      {/* Minimalist Interactive Scroll Progress & Section Spy */}
      <ScrollProgressIndicator theme={theme} activeSection={activeSection} />
    </div>
  );
}
