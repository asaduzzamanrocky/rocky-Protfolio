import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Settings, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Laptop,
  PhoneCall
} from 'lucide-react';
import { ThemeMode } from '../types';
import { detectDevice } from '../services/analyticsService';

interface NavbarProps {
  theme: ThemeMode;
  onThemeChange: (theme: ThemeMode) => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  theme,
  onThemeChange,
  activeSection,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDevice, setUserDevice] = useState<'Mac' | 'iPhone' | 'Windows' | 'Android' | 'Other'>('Mac');

  useEffect(() => {
    setUserDevice(detectDevice());
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#about' },
    { name: 'Works & 60+ Sites', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const isLight = theme === 'light-contrast';

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? isLight 
            ? 'bg-white/90 backdrop-blur-xl border-b border-slate-200 shadow-sm' 
            : 'bg-[#08090d]/85 backdrop-blur-xl border-b border-orange-500/20 shadow-2xl shadow-orange-950/20' 
          : 'bg-transparent'
      }`}
    >
      {/* Top Laser Highlight line */}
      <div className={`h-[2px] w-full transition-all duration-500 ${
        theme === 'dark-crimson' ? 'bg-gradient-to-r from-transparent via-orange-500 to-transparent shadow-[0_0_10px_#f97316]' :
        theme === 'dark-emerald' ? 'bg-gradient-to-r from-transparent via-emerald-500 to-transparent shadow-[0_0_10px_#10b981]' :
        theme === 'dark-cyan' ? 'bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_10px_#22d3ee]' :
        'bg-slate-300'
      }`} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Brand Identity - Personal Minimalist Branding */}
          <a 
            href="#hero" 
            onClick={(e) => handleNavClick(e, '#hero')}
            className="flex items-center gap-3 group focus:outline-none"
            id="nav-brand-link"
          >
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-gradient-to-br from-orange-500 to-red-600 text-white flex items-center justify-center font-display font-black text-xs sm:text-sm tracking-wider shadow-md shadow-orange-500/30 group-hover:scale-105 transition-transform">
              AR
            </div>
            <div className="flex flex-col">
              <span className={`font-display font-bold text-base sm:text-lg tracking-tight leading-tight transition-colors ${
                isLight ? 'text-slate-900' : 'text-white'
              }`}>
                Asaduzzaman Rocky
              </span>
              <span className="text-[11px] font-mono text-orange-400">
                Lead Architect & Director
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium">
            <a
              href="#hero"
              onClick={(e) => handleNavClick(e, '#hero')}
              className={`transition-colors ${
                activeSection === 'hero'
                  ? 'text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Home
            </a>
            <a
              href="#about"
              onClick={(e) => handleNavClick(e, '#about')}
              className={`transition-colors ${
                activeSection === 'about'
                  ? 'text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              About
            </a>
            <a
              href="#projects"
              onClick={(e) => handleNavClick(e, '#projects')}
              className={`transition-colors ${
                activeSection === 'projects'
                  ? 'text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Works & 60+ Sites
            </a>
            <a
              href="#experience"
              onClick={(e) => handleNavClick(e, '#experience')}
              className={`transition-colors ${
                activeSection === 'experience'
                  ? 'text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Experience
            </a>
            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, '#contact')}
              className={`transition-colors ${
                activeSection === 'contact'
                  ? 'text-white font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Contact
            </a>
          </nav>

          {/* Clean Action Utilities */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Theme Toggle Button */}
            <button
              onClick={() => {
                if (theme === 'dark-crimson') onThemeChange('dark-emerald');
                else if (theme === 'dark-emerald') onThemeChange('dark-cyan');
                else if (theme === 'dark-cyan') onThemeChange('light-contrast');
                else onThemeChange('dark-crimson');
              }}
              title="Cycle Theme: Crimson / Emerald / Cyan / Light"
              className={`p-2 sm:p-2.5 rounded-full border transition-all text-xs font-mono flex items-center justify-center ${
                isLight
                  ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                  : 'bg-white/5 border-white/10 text-slate-300 hover:border-white/20 hover:text-white'
              }`}
              id="theme-switcher-btn"
            >
              {isLight ? (
                <Sun className="w-4 h-4 text-amber-500" />
              ) : (
                <Moon className={`w-4 h-4 ${
                  theme === 'dark-crimson' ? 'text-orange-500' :
                  theme === 'dark-emerald' ? 'text-emerald-400' :
                  'text-cyan-400'
                }`} />
              )}
            </button>

            {/* "Get in touch" pill button with arrow circle */}
            <a
              href="#contact"
              onClick={(e) => handleNavClick(e, '#contact')}
              className="flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 rounded-full font-medium text-xs sm:text-sm bg-white text-black hover:bg-orange-500 hover:text-white transition-all duration-300 group shadow-lg"
              id="nav-get-in-touch-btn"
            >
              <span className="font-semibold">Get in touch</span>
              <span className="w-5 h-5 rounded-full bg-orange-500 group-hover:bg-white text-white group-hover:text-orange-500 flex items-center justify-center transition-colors">
                <span className="transform -rotate-45 font-bold text-xs">→</span>
              </span>
            </a>

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`md:hidden p-2 rounded-xl border ${
                isLight ? 'bg-slate-100 border-slate-300 text-slate-800' : 'bg-white/5 border-white/10 text-white'
              }`}
              id="mobile-menu-toggle-btn"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className={`lg:hidden border-b px-4 pt-3 pb-6 space-y-3 ${
          isLight ? 'bg-white/95 border-slate-200 text-slate-900 shadow-xl' : 'bg-[#0a0c12]/98 border-orange-500/20 text-white shadow-2xl backdrop-blur-2xl'
        }`}>
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Laptop className="w-4 h-4 text-orange-500" />
              <span className="text-xs font-mono text-slate-400">Device: {userDevice} (Optimized)</span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 font-mono">
              60+ Live Sites
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className={`px-3 py-2 rounded-xl text-xs font-medium ${
                  activeSection === link.href.substring(1)
                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                    : isLight ? 'bg-slate-100 text-slate-700' : 'bg-white/5 text-slate-300'
                }`}
              >
                {link.name}
              </a>
            ))}
          </div>

          <div className="pt-2 flex flex-col gap-2">
            <a
              href="https://wa.me/8801714722651"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 text-white text-xs font-medium flex items-center justify-center gap-2"
            >
              <PhoneCall className="w-4 h-4" />
              <span>WhatsApp Direct (+880 1714-722651)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
