import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ExternalLink, 
  Search, 
  Layers, 
  CheckCircle2, 
  Sparkles, 
  ArrowUpRight, 
  Filter, 
  Globe, 
  X,
  Zap,
  TrendingUp,
  ShieldAlert
} from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { Project, ThemeMode } from '../types';
import { AnalyticsService } from '../services/analyticsService';

interface ProjectsSectionProps {
  theme: ThemeMode;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({ theme }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModalProject, setActiveModalProject] = useState<Project | null>(null);
  const [layoutMode, setLayoutMode] = useState<'grid' | 'editorial'>('grid');
  const [visibleCount, setVisibleCount] = useState<number>(16);

  const isLight = theme === 'light-contrast';

  const categories = [
    { id: 'all', label: 'All Projects (60+)', count: PROJECTS.length },
    { id: 'healthcare', label: 'Healthcare & Care Facilities', count: PROJECTS.filter(p => p.category === 'healthcare').length },
    { id: 'corporate', label: 'Corporate & Tech Solutions', count: PROJECTS.filter(p => p.category === 'corporate').length },
    { id: 'ecommerce', label: 'E-Commerce & WooCommerce', count: PROJECTS.filter(p => p.category === 'ecommerce').length },
    { id: 'uiux', label: 'UI/UX Case Studies (Behance)', count: PROJECTS.filter(p => p.category === 'uiux').length },
  ];

  const filteredProjects = PROJECTS.filter((project) => {
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    const matchesSearch = 
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.domain.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.technologies.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleLiveClick = (project: Project, e: React.MouseEvent) => {
    AnalyticsService.trackEvent('project_click', `Visited: ${project.title}`, {
      projectId: project.id,
      domain: project.domain,
      category: project.category
    });
  };

  return (
    <section id="projects" className={`py-24 sm:py-32 relative transition-colors ${
      isLight ? 'bg-white text-slate-900' : 'bg-[#08090d] text-slate-100'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Header with Scroll Animation */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12"
        >
          <div className="space-y-3">
            <span className="font-mono text-xs font-bold text-orange-500 tracking-widest uppercase block">
              Production Ecosystem // 60+ Live Platforms
            </span>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl tracking-tight">
              Featured Client Deployments &{' '}
              <span className="text-orange-500">
                Case Studies
              </span>
            </h2>
            <p className="text-sm sm:text-base text-slate-400 max-w-2xl">
              Engineered for peak performance, sub-2s mobile loading, and measurable conversion gains across global markets.
            </p>
          </div>

          {/* Search Bar */}
          <div className="w-full md:w-72 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, tech, domain..."
              className={`w-full pl-10 pr-4 py-2.5 rounded-full text-xs font-mono border focus:outline-none transition-all ${
                isLight 
                  ? 'bg-slate-50 border-slate-300 text-slate-900 focus:border-slate-500' 
                  : 'bg-white/5 border-white/10 text-white placeholder-slate-500 focus:border-orange-500/50 focus:bg-white/[0.07]'
              }`}
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </motion.div>

        {/* Filter Pills & View Mode Switcher */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8"
        >
          <div className="flex flex-wrap items-center gap-2">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3.5 py-1.5 rounded-full text-xs font-medium font-mono transition-all flex items-center gap-2 ${
                    isSelected
                      ? isLight
                        ? 'bg-slate-900 text-white shadow-md'
                        : 'bg-orange-500/20 text-orange-400 border border-orange-500/50 shadow-[0_0_15px_rgba(240,90,40,0.25)]'
                      : isLight
                      ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      : 'bg-white/[0.03] text-slate-400 hover:text-white hover:bg-white/[0.08] border border-white/5'
                  }`}
                >
                  <span>{cat.label}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-orange-500/30 text-white' : 'bg-white/10 text-slate-400'
                  }`}>
                    {cat.count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 p-1 rounded-full bg-white/[0.03] border border-white/10 text-xs font-mono self-start sm:self-auto">
            <button
              onClick={() => setLayoutMode('editorial')}
              className={`px-3.5 py-1.5 rounded-full transition-all ${
                layoutMode === 'editorial'
                  ? 'bg-orange-500 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Editorial Showcase
            </button>
            <button
              onClick={() => setLayoutMode('grid')}
              className={`px-3.5 py-1.5 rounded-full transition-all ${
                layoutMode === 'grid'
                  ? 'bg-orange-500 text-white shadow-md font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Matrix Grid ({filteredProjects.length})
            </button>
          </div>
        </motion.div>

        {/* Editorial Showcase Mode (Storytelling Cards with Scroll Animation) */}
        {layoutMode === 'editorial' ? (
          <div className="space-y-10 mb-12">
            {filteredProjects.map((project, index) => {
              const numStr = (index + 1).toString().padStart(2, '0');
              return (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 35 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: false, amount: 0.2 }}
                  transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                  className={`relative rounded-3xl border p-6 sm:p-10 transition-all duration-500 group overflow-hidden ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 hover:border-slate-300 shadow-sm'
                      : 'bg-gradient-to-br from-white/[0.03] via-white/[0.01] to-black border-white/10 hover:border-orange-500/40 shadow-2xl'
                  }`}
                >
                  {/* Subtle Giant Background Number */}
                  <div className="absolute right-4 -top-8 font-display font-black text-8xl sm:text-9xl text-white/[0.03] group-hover:text-orange-500/[0.07] pointer-events-none select-none transition-colors">
                    {numStr}
                  </div>

                  <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                    
                    {/* Left Meta & Story Column */}
                    <div className="lg:col-span-8 space-y-4">
                      
                      <div className="flex flex-wrap items-center gap-3">
                        <span className="font-mono text-xs text-orange-500 font-bold tracking-wider">
                          {numStr} // {project.category.toUpperCase()}
                        </span>

                        {project.metrics && (
                          <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1.5">
                            <TrendingUp className="w-3 h-3" />
                            {project.metrics}
                          </span>
                        )}
                      </div>

                      <h3 className="font-display font-extrabold text-2xl sm:text-3xl lg:text-4xl text-white group-hover:text-orange-400 transition-colors">
                        {project.title}
                      </h3>

                      <p className="text-sm sm:text-base text-slate-400 leading-relaxed max-w-3xl">
                        {project.description}
                      </p>

                      {/* Tech Chips */}
                      <div className="flex flex-wrap gap-2 pt-1">
                        {project.technologies.map((tech) => (
                          <span
                            key={tech}
                            className="text-xs font-mono px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>

                      {/* Live Domain Bar */}
                      <div className="flex items-center gap-2 text-xs font-mono text-slate-400 pt-2">
                        <Globe className="w-3.5 h-3.5 text-orange-500" />
                        <span className="text-slate-300 font-semibold">{project.domain}</span>
                      </div>

                    </div>

                    {/* Right Interactive CTA Column */}
                    <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col items-stretch justify-center gap-3">
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => handleLiveClick(project, e)}
                        className="px-6 py-3.5 rounded-full bg-orange-500 hover:bg-orange-600 text-white font-sans text-xs font-bold tracking-wide uppercase flex items-center justify-center gap-2 shadow-lg shadow-orange-500/30 transition-all group-hover:scale-[1.02]"
                      >
                        <span>Launch Live Website</span>
                        <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                      </a>

                      <button
                        onClick={() => setActiveModalProject(project)}
                        className="px-6 py-3.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center justify-center gap-2 transition-all"
                      >
                        <Layers className="w-3.5 h-3.5 text-orange-400" />
                        <span>Inspect Architecture</span>
                      </button>
                    </div>

                  </div>
                </motion.div>
              );
            })}
          </div>
        ) : (
          /* Matrix Grid Mode (4x4 Section: 4 Columns Grid) */
          <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {filteredProjects.slice(0, visibleCount).map((project, index) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 25 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: false, amount: 0.1 }}
                  transition={{ duration: 0.45, delay: (index % 4) * 0.08 }}
                  className={`rounded-2xl border p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 group hover:-translate-y-1 ${
                    isLight
                      ? 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:shadow-xl'
                      : 'bg-[#0e1017] border-white/10 hover:border-orange-500/40 hover:shadow-2xl hover:shadow-orange-950/20'
                  }`}
                >
                  <div>
                    {/* Top Meta Bar */}
                    <div className="flex items-center justify-between gap-1.5 mb-3">
                      <span className={`text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                        project.category === 'healthcare' 
                          ? 'bg-red-500/10 text-red-400 border-red-500/20'
                          : project.category === 'ecommerce'
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : project.category === 'uiux'
                          ? 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                          : 'bg-orange-500/10 text-orange-400 border-orange-500/20'
                      }`}>
                        {project.category}
                      </span>

                      {project.metrics && (
                        <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                          <TrendingUp className="w-2.5 h-2.5" />
                          {project.metrics}
                        </span>
                      )}
                    </div>

                    {/* Project Title & Domain */}
                    <h3 className="font-display font-bold text-base text-white group-hover:text-orange-400 transition-colors line-clamp-1">
                      {project.title}
                    </h3>
                    <div className="flex items-center gap-1 text-xs font-mono text-slate-400 mt-0.5 mb-2.5">
                      <Globe className="w-3 h-3 text-orange-500 shrink-0" />
                      <span className="truncate">{project.domain}</span>
                    </div>

                    {/* Description */}
                    <p className="text-xs text-slate-400 leading-relaxed line-clamp-2 mb-3">
                      {project.description}
                    </p>

                    {/* Tech Chips */}
                    <div className="flex flex-wrap gap-1 mb-4">
                      {project.technologies.slice(0, 3).map((tech) => (
                        <span
                          key={tech}
                          className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-slate-300"
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies.length > 3 && (
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-slate-500">
                          +{project.technologies.length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Bottom Card Actions */}
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                    <button
                      onClick={() => setActiveModalProject(project)}
                      className="text-xs font-mono text-slate-300 hover:text-white flex items-center gap-1 hover:underline"
                    >
                      <Layers className="w-3 h-3 text-orange-400" />
                      <span>Specs</span>
                    </button>

                    <a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => handleLiveClick(project, e)}
                      className="px-3 py-1 rounded-full text-xs font-mono font-medium text-white bg-orange-500 hover:bg-orange-600 flex items-center gap-1 transition-all shadow-sm"
                    >
                      <span>Live Site</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                </motion.div>
              ))}
            </div>

            {/* 4x4 Section Pagination and View Controls */}
            {filteredProjects.length > 16 && (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/10">
                <span className="text-xs font-mono text-slate-400">
                  Showing {Math.min(visibleCount, filteredProjects.length)} of {filteredProjects.length} Verified Production Platforms (4×4 Grid)
                </span>

                <div className="flex items-center gap-2">
                  {visibleCount < filteredProjects.length ? (
                    <>
                      <button
                        onClick={() => setVisibleCount((prev) => prev + 16)}
                        className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-200 border border-white/15 text-xs font-mono transition-colors"
                      >
                        Load Next 16 (+4×4)
                      </button>
                      <button
                        onClick={() => setVisibleCount(filteredProjects.length)}
                        className="px-4 py-2 rounded-full bg-orange-500 hover:bg-orange-600 text-white text-xs font-mono font-medium transition-colors"
                      >
                        View All {filteredProjects.length}
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setVisibleCount(16)}
                      className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 border border-white/15 text-xs font-mono"
                    >
                      Reset to 4×4 Grid (16)
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {filteredProjects.length === 0 && (
          <div className="p-12 text-center rounded-2xl border border-white/10 bg-white/[0.02] space-y-3">
            <p className="text-sm text-slate-400">No projects found matching "{searchQuery}".</p>
            <button
              onClick={() => { setSearchQuery(''); setSelectedCategory('all'); }}
              className="px-4 py-2 rounded-xl bg-red-600 text-white text-xs font-mono"
            >
              Reset Filters
            </button>
          </div>
        )}

      </div>

      {/* Project Detail Modal */}
      {activeModalProject && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className={`relative w-full max-w-2xl rounded-3xl border p-6 sm:p-8 shadow-2xl my-8 ${
            isLight ? 'bg-white border-slate-200 text-slate-900' : 'bg-[#0e1017] border-red-500/30 text-white'
          }`}>
            
            <button
              onClick={() => setActiveModalProject(null)}
              className="absolute top-5 right-5 p-2 rounded-xl bg-white/10 hover:bg-red-600 text-white transition-all"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[11px] font-mono uppercase px-2.5 py-0.5 rounded bg-red-500/20 text-red-400">
                    {activeModalProject.category}
                  </span>
                  {activeModalProject.metrics && (
                    <span className="text-[11px] font-mono px-2.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">
                      {activeModalProject.metrics}
                    </span>
                  )}
                </div>
                <h3 className="font-display font-extrabold text-2xl sm:text-3xl text-white">
                  {activeModalProject.title}
                </h3>
                <a 
                  href={activeModalProject.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs font-mono text-red-400 hover:underline flex items-center gap-1 mt-1"
                >
                  <Globe className="w-3.5 h-3.5" />
                  <span>https://{activeModalProject.domain}</span>
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </div>

              <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
                <h4 className="font-mono text-xs uppercase tracking-wider text-slate-400">
                  Architecture & Strategic Execution
                </h4>
                <p>{activeModalProject.longDescription || activeModalProject.description}</p>
              </div>

              {/* Key Features List */}
              <div className="space-y-3">
                <h4 className="font-mono text-xs uppercase tracking-wider text-slate-400">
                  Key Delivered Capabilities
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {activeModalProject.features.map((feat) => (
                    <div key={feat} className="flex items-center gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tech Stack Chips */}
              <div className="space-y-2">
                <h4 className="font-mono text-xs uppercase tracking-wider text-slate-400">
                  Technologies Employed
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activeModalProject.technologies.map((t) => (
                    <span key={t} className="px-3 py-1 rounded-xl text-xs font-mono bg-white/5 border border-white/10 text-slate-200">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                <button
                  onClick={() => setActiveModalProject(null)}
                  className="px-4 py-2 rounded-xl text-xs font-mono text-slate-400 hover:text-white"
                >
                  Close Window
                </button>

                <div className="flex items-center gap-2">
                  <a
                    href={activeModalProject.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => handleLiveClick(activeModalProject, e)}
                    className="px-5 py-2.5 rounded-xl font-display font-semibold text-xs text-white bg-red-600 hover:bg-red-500 flex items-center gap-2 shadow-[0_0_15px_rgba(239,68,68,0.5)]"
                  >
                    <span>Launch Live Production Domain</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
};
