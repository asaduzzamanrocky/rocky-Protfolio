import React from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle2, 
  GraduationCap, 
  Sparkles,
  MapPin,
  Mail,
  Phone,
  Target,
  Briefcase,
  TrendingUp,
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { ThemeMode } from '../types';

interface AboutSectionProps {
  theme: ThemeMode;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ theme }) => {
  const isLight = theme === 'light-contrast';

  const pillars = [
    {
      title: 'Understand the Problem',
      desc: 'Conduct deep discovery, user research, and stakeholder audits to identify conversion blockers and technical debt.',
      icon: Target,
    },
    {
      title: 'Design the Solution',
      desc: 'Craft component-driven design systems in Figma and Adobe XD emphasizing accessibility and high-converting user pathways.',
      icon: Sparkles,
    },
    {
      title: 'Build the Experience',
      desc: 'Engineer resilient WordPress & WooCommerce architecture, custom post types, ACF matrices, and clean PHP/JS integrations.',
      icon: Briefcase,
    },
    {
      title: 'Optimize for Growth',
      desc: 'Speed hardening (Core Web Vitals sub-1s LCP), technical SEO schemas, and conversion rate optimization (CRO).',
      icon: TrendingUp,
    },
  ];

  return (
    <section id="about" className={`py-24 sm:py-32 relative overflow-hidden transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-[#08090d] text-slate-100'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center text-center space-y-3 mb-16 sm:mb-20"
        >
          <span className="font-mono text-xs font-bold text-orange-500 tracking-widest uppercase">
            Executive Profile & Methodology
          </span>
          <h2 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl tracking-tight max-w-3xl">
            Fusing Technical Architecture With{' '}
            <span className="text-orange-500">
              Business Growth
            </span>
          </h2>
          <p className="text-sm sm:text-base text-slate-400 max-w-2xl">
            Over 10 years converting complex operational requirements into high-converting, resilient digital platforms.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
          
          {/* Left Column: Clean Architectural Profile Card */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-5"
          >
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xl space-y-6 ${
              isLight ? 'bg-white border-slate-200' : 'bg-[#0e1017] border-white/10'
            }`}>
              
              {/* Profile Monogram Header */}
              <div className="flex items-center gap-4 border-b border-white/10 pb-5">
                <div className="w-14 h-14 rounded-2xl bg-orange-500 text-white flex items-center justify-center font-display font-extrabold text-xl shadow-lg shadow-orange-500/30">
                  AR
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg text-white">
                    Asaduzzaman Rocky
                  </h3>
                  <p className="text-xs font-mono text-slate-400">
                    Lead WordPress Architect • 10+ Yrs
                  </p>
                </div>
              </div>

              {/* Core Statistics Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className={`p-3 rounded-2xl border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-white/[0.02] border-white/5'
                }`}>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Experience</span>
                  <span className="text-white font-bold text-sm">10+ Years</span>
                </div>

                <div className={`p-3 rounded-2xl border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-white/[0.02] border-white/5'
                }`}>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Track Record</span>
                  <span className="text-orange-400 font-bold text-sm">60+ Live Sites</span>
                </div>

                <div className={`p-3 rounded-2xl border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-white/[0.02] border-white/5'
                }`}>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Location</span>
                  <span className="text-slate-300 font-medium">Barishal, BD</span>
                </div>

                <div className={`p-3 rounded-2xl border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-white/[0.02] border-white/5'
                }`}>
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Consulting</span>
                  <span className="text-emerald-400 font-bold">Open for Q3/Q4</span>
                </div>
              </div>

              {/* Verified Degree */}
              <div className={`p-4 rounded-2xl border flex items-start gap-3 ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-white/[0.02] border-white/5'
              }`}>
                <GraduationCap className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-white">
                    {PERSONAL_INFO.education.degree}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {PERSONAL_INFO.education.institution} (Graduated 2018)
                  </div>
                </div>
              </div>

              {/* Direct WhatsApp Callout */}
              <a
                href="https://wa.me/8801714722651?text=Hello%20Rocky,%20let%20us%20discuss%20a%20project."
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-full bg-white/5 hover:bg-orange-500/20 text-slate-200 hover:text-white border border-white/10 hover:border-orange-500/40 font-mono text-xs flex items-center justify-between transition-all"
              >
                <span className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>WhatsApp: +880 1714-722651</span>
                </span>
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
              </a>

            </div>
          </motion.div>

          {/* Right Column: Bio Narrative & 4 Pillars */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: false, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="lg:col-span-7 space-y-6"
          >
            <div className="space-y-4 text-slate-300 leading-relaxed text-base">
              <p className="font-display font-semibold text-xl sm:text-2xl text-white leading-snug">
                "I don’t just build websites that look good. I engineer user-friendly, high-speed, and conversion-focused systems designed to build trust, attract customers, and scale revenue."
              </p>

              <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
                Having architected <strong className="text-white">60+ live WordPress sites</strong> across healthcare, corporate, e-commerce, and SaaS verticals, I transform ambitious business goals into durable digital assets.
              </p>

              <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
                As the CEO & Lead WordPress Architect at <strong className="text-white">Dev Design Grow</strong> and Digital Growth Strategist at <strong className="text-white">Najah Brand Elevation (Minnesota, US)</strong>, I guide projects from heuristic wireframing to enterprise cloud deployments with sub-second performance.
              </p>
            </div>

            {/* Strategic 4 Pillars */}
            <div className="pt-4">
              <span className="text-xs font-mono uppercase tracking-wider text-orange-400 mb-3 block font-bold">
                Methodology & Growth Architecture
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {pillars.map((p, idx) => {
                  const Icon = p.icon;
                  return (
                    <motion.div 
                      key={p.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: false, amount: 0.2 }}
                      transition={{ duration: 0.5, delay: 0.1 * idx }}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                        isLight 
                          ? 'bg-white border-slate-200 hover:border-slate-300' 
                          : 'bg-white/[0.02] border-white/10 hover:border-orange-500/30'
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <div className="p-2 rounded-xl bg-orange-500/10 text-orange-400">
                          <Icon className="w-4 h-4" />
                        </div>
                        <span className="font-display font-bold text-sm text-white">
                          0{idx + 1}. {p.title}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        {p.desc}
                      </p>
                    </motion.div>
                  );
                })}
              </div>
            </div>

          </motion.div>

        </div>

      </div>
    </section>
  );
};
