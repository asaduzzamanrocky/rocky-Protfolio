import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { AnalyticsService } from '../services/analyticsService';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);

  const handleClick = () => {
    AnalyticsService.trackEvent('button_click', 'Floating WhatsApp Widget Click', {
      buttonId: 'floating-whatsapp-btn',
      channel: 'whatsapp',
      target: PERSONAL_INFO.links.whatsapp,
      conversionIntent: 'direct_chat_inquiry',
      timestamp: new Date().toISOString(),
    });
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2">
      {/* Tooltip speech bubble */}
      {showTooltip && (
        <div className="relative bg-[#0d0f17] text-white border border-emerald-500/40 p-3 rounded-2xl shadow-xl shadow-black/60 max-w-xs text-xs font-mono flex items-start gap-2.5 animate-bounce">
          <div>
            <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Rocky is Online</span>
            </div>
            <p className="text-slate-300 text-[11px] mt-0.5">
              Need a high-converting website or speed audit? Message me directly.
            </p>
          </div>
          <button
            onClick={() => setShowTooltip(false)}
            className="text-slate-400 hover:text-white p-0.5"
          >
            <X className="w-3 h-3" />
          </button>
          {/* Caret */}
          <div className="absolute -bottom-1.5 right-6 w-3 h-3 bg-[#0d0f17] border-r border-b border-emerald-500/40 rotate-45" />
        </div>
      )}

      {/* Floating Button */}
      <a
        href={PERSONAL_INFO.links.whatsapp}
        target="_blank"
        rel="noopener noreferrer"
        onClick={handleClick}
        className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white flex items-center justify-center shadow-[0_0_25px_rgba(16,185,129,0.5)] hover:shadow-[0_0_35px_rgba(16,185,129,0.8)] transition-all hover:scale-105 group"
        title="Instant WhatsApp Support: +880 1714-722651"
        id="floating-whatsapp-btn"
      >
        <MessageCircle className="w-7 h-7 fill-white/20 transition-transform group-hover:scale-110" />
        {/* Pulsing beacon ring */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-[#08090d]" />
        </span>
      </a>
    </div>
  );
};
