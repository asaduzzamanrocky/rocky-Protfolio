import React, { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  ExternalLink,
  Globe2
} from 'lucide-react';
import { ThemeMode } from '../types';
import { ToolLogosMarquee } from './ToolLogosMarquee';
import { PERSONAL_INFO } from '../data/portfolioData';

interface HeroSectionProps {
  theme: ThemeMode;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ theme }) => {
  const isLight = theme === 'light-contrast';
  const sectionRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Smooth scroll transform
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end start'],
  });

  const heroY = useTransform(scrollYProgress, [0, 1], [0, 60]);
  const opacityFade = useTransform(scrollYProgress, [0, 0.9], [1, 0.5]);

  // Ensure autoplay on mount
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {
        // Handled silently for browser autoplay compliance
      });
    }
  }, []);

  return (
    <section 
      ref={sectionRef} 
      id="hero" 
      className="relative w-full pt-2 sm:pt-4 pb-12 overflow-hidden"
    >
      {/* Curved Container Card */}
      <motion.div 
        style={{ y: heroY, opacity: opacityFade }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className={`relative mx-auto max-w-[1440px] rounded-b-[40px] md:rounded-b-[56px] overflow-hidden border-b border-x ${
          isLight
            ? 'bg-slate-950 border-slate-700/40 text-white'
            : 'bg-[#07080c] border-white/10 text-white'
        }`}
      >
        {/* Unedited Wide Video Background */}
        <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-0">
          <video
            ref={videoRef}
            src="/hero-video.mp4"
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            className="w-full h-full object-cover object-center"
          />
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-10 lg:px-12 pt-20 sm:pt-28 pb-14 sm:pb-16">
          
          {/* Main Hero Split Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center min-h-[460px]">
            
            {/* Left Column: Eyebrow + Huge "Creative Director" Display Heading + Core Bio */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{ duration: 0.7, delay: 0.1 }}
              className="lg:col-span-7 z-20 space-y-6"
            >
              <div className="flex flex-wrap items-center gap-3">
                <span className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-mono bg-black/70 text-orange-300 border border-orange-500/30 backdrop-blur-md shadow-md">
                  <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />
                  <span>Available for Strategic Projects</span>
                </span>
                <span className="text-xs font-mono text-slate-300 bg-black/50 px-3 py-1 rounded-full border border-white/10 backdrop-blur-sm">
                  Barishal, Bangladesh • Worldwide Remote
                </span>
              </div>

              <div className="space-y-2">
                <div className="text-sm sm:text-base font-medium text-orange-400 tracking-wide font-mono drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                  Hey, I'm Asaduzzaman Rocky —
                </div>
                <h1 className="font-display font-extrabold text-5xl sm:text-6xl md:text-7xl lg:text-8xl tracking-tight leading-[0.95] text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.9)]">
                  Creative <br />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-orange-100 to-orange-400">
                    Director
                  </span>
                </h1>
              </div>

              <h2 className="font-display font-bold text-2xl sm:text-3xl text-white leading-snug drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
                Great design should feel invisible.
              </h2>
              
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed max-w-2xl drop-shadow-[0_2px_6px_rgba(0,0,0,0.9)]">
                From logo to language, I build brands that connect and convert. Merging 10+ years of high-converting WordPress architecture, headless CMS engineering, and refined aesthetic systems to launch flagships that scale.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <a
                  href="#contact"
                  className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-orange-500 hover:bg-orange-600 text-white font-semibold text-sm transition-all duration-300 shadow-xl shadow-orange-500/40 group"
                  id="hero-start-project-btn"
                >
                  <span>Start A Project</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </a>

                <a
                  href="#projects"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/25 text-sm font-medium transition-all backdrop-blur-md shadow-lg"
                  id="hero-explore-sites-btn"
                >
                  <span>Explore 60+ Sites</span>
                </a>

                <a
                  href={PERSONAL_INFO.links.agency}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-4 py-3.5 text-xs font-mono text-slate-300 hover:text-orange-400 transition-colors bg-black/40 rounded-full border border-white/10 backdrop-blur-sm"
                >
                  <Globe2 className="w-4 h-4" />
                  <span>Dev Design Grow</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </motion.div>

            {/* Right Column: Architectural Highlights & Executive Metrics Matrix */}
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: false, amount: 0.3 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="lg:col-span-5 z-20 space-y-4"
            >
              {/* Executive Overview Card */}
              <div className="p-6 sm:p-8 rounded-3xl bg-black/65 border border-white/15 backdrop-blur-xl shadow-2xl space-y-6">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-mono text-slate-400 uppercase tracking-wider">Leadership</div>
                      <div className="text-sm font-bold text-white">CEO & Lead Architect</div>
                    </div>
                  </div>
                  <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-white/10 text-orange-300 border border-white/15">
                    10+ Yrs Track Record
                  </span>
                </div>

                {/* 2x2 Key Quantitative Metrics */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-white/[0.05] border border-white/10">
                    <div className="text-2xl sm:text-3xl font-display font-extrabold text-orange-400">60+</div>
                    <div className="text-xs font-mono text-slate-300 mt-1">Live Platforms Built</div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/[0.05] border border-white/10">
                    <div className="text-2xl sm:text-3xl font-display font-extrabold text-white">10+</div>
                    <div className="text-xs font-mono text-slate-300 mt-1">Years CMS Mastery</div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/[0.05] border border-white/10">
                    <div className="text-2xl sm:text-3xl font-display font-extrabold text-white">99.8%</div>
                    <div className="text-xs font-mono text-slate-300 mt-1">Client Retention</div>
                  </div>

                  <div className="p-4 rounded-2xl bg-white/[0.05] border border-white/10">
                    <div className="text-2xl sm:text-3xl font-display font-extrabold text-orange-400">4.2×</div>
                    <div className="text-xs font-mono text-slate-300 mt-1">Avg Conversion Uplift</div>
                  </div>
                </div>

                {/* Core Disciplines List */}
                <div className="space-y-2.5 pt-2 border-t border-white/10 text-xs font-mono text-slate-300">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                    <span>Bespoke WordPress & WooCommerce Engineering</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                    <span>Brand Direction & High-Converting Web Architecture</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                    <span>Full-Stack Security, Headless & Performance Tuning</span>
                  </div>
                </div>
              </div>
            </motion.div>

          </div>

        </div>

        {/* Bottom Scrolling Tools Logos Marquee */}
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="relative z-10 border-t border-white/10 bg-black/80 backdrop-blur-md px-4 sm:px-8 py-4 overflow-hidden"
        >
          <ToolLogosMarquee />
        </motion.div>

      </motion.div>
    </section>
  );
};
