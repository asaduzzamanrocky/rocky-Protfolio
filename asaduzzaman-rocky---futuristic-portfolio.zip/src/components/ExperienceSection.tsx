import React from 'react';
import { motion } from 'motion/react';
import { 
  Briefcase, 
  MapPin, 
  Calendar, 
  Sparkles,
  Award,
  ArrowUpRight
} from 'lucide-react';
import { EXPERIENCES } from '../data/portfolioData';
import { ThemeMode } from '../types';

interface ExperienceSectionProps {
  theme: ThemeMode;
}

export const ExperienceSection: React.FC<ExperienceSectionProps> = ({ theme }) => {
  const isLight = theme === 'light-contrast';

  return (
    <section id="experience" className={`py-24 sm:py-32 relative transition-colors ${
      isLight ? 'bg-white text-slate-900' : 'bg-[#08090d] text-slate-100'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title with Scroll Animation */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: false, amount: 0.3 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col items-center text-center space-y-3 mb-16 sm:mb-20"
        >
          <span className="font-mono text-xs font-bold text-orange-500 tracking-widest uppercase block">
            Career Track Record & Leadership
          </span>
          <h2 className="font-display font-extrabold text-3xl sm:text-4xl lg:text-5xl tracking-tight">
            Professional Experience &{' '}
            <span className="text-orange-500">
              Agency Impact
            </span>
          </h2>
          <p className="text-sm sm:text-base text-slate-400 max-w-2xl">
            Over 10 years of driving digital growth, agency leadership, and engineering resilient digital experiences for global clients.
          </p>
        </motion.div>

        {/* 2x2 Grid Layout for Better View */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {EXPERIENCES.map((exp, index) => (
            <motion.div
              key={exp.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false, amount: 0.2 }}
              transition={{ duration: 0.6, delay: (index % 2) * 0.15 }}
              className={`rounded-3xl border p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 group hover:-translate-y-1 ${
                isLight
                  ? 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:shadow-xl'
                  : 'bg-[#0f1118] border-white/10 hover:border-orange-500/40 hover:shadow-2xl hover:shadow-orange-950/20'
              }`}
            >
              <div>
                {/* Card Header & Icon */}
                <div className="flex items-start justify-between gap-4 mb-5">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 group-hover:scale-105 transition-transform">
                      <Briefcase className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-display font-bold text-lg sm:text-xl text-white group-hover:text-orange-400 transition-colors">
                        {exp.role}
                      </h3>
                      <p className="text-sm font-semibold text-orange-400">
                        {exp.company}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs font-mono font-bold text-white/30 group-hover:text-orange-500/40 transition-colors">
                    0{index + 1}
                  </span>
                </div>

                {/* Period & Location Pills */}
                <div className="flex flex-wrap items-center gap-2 mb-5">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-mono bg-white/5 border border-white/10 text-slate-300">
                    <Calendar className="w-3.5 h-3.5 text-orange-400" />
                    <span>{exp.period}</span>
                  </span>

                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-mono bg-white/5 border border-white/10 text-slate-400">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{exp.location}</span>
                  </span>
                </div>

                {/* Highlights List */}
                <ul className="space-y-2.5 mb-6">
                  {exp.bulletPoints.map((h, i) => (
                    <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300 leading-relaxed">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0 mt-2" />
                      <span>{h}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Technologies / Tags */}
              <div className="flex flex-wrap gap-1.5 pt-4 border-t border-white/10">
                {exp.tags.map((tech) => (
                  <span
                    key={tech}
                    className="text-[11px] font-mono px-2.5 py-0.5 rounded-full bg-white/5 text-slate-300 border border-white/10"
                  >
                    {tech}
                  </span>
                ))}
              </div>

            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};
